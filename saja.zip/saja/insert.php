<?php
$con=mysqli_connect('localhost','root','','task2') or die("unable to connect");

if(isset($_POST['r_distance'])){
  $distance=$_POST['r_distance'];
  $sql="INSERT INTO movement( move , distance ) VALUES('R','$distance')";
  $result=mysqli_query($con,$sql);

  if($result){
      $sql1="SELECT *  from movement ";
      $result1=mysqli_query($con,$sql1);
      if($result1){
      while($row=mysqli_fetch_assoc($result1)){
          echo '<tr>
                  <th>  '.$row['move'].'</th>
                  <th>  '.$row['distance'].'</th> 
                </tr>';
                
      }
    }

  } else {
    
  }
}else if(isset($_POST['l_distance'])){
  $distance=$_POST['l_distance'];
  $sql="INSERT INTO movement( move , distance ) VALUES('L','$distance')";
  $result=mysqli_query($con,$sql);
  if($result){
    $sql1="SELECT *  from movement ";
      $result1=mysqli_query($con,$sql1);
      if($result1){
      while($row=mysqli_fetch_assoc($result1)){
          echo '<tr>
                  <th>  '.$row['move'].'</th>
                  <th>  '.$row['distance'].'</th> 
                </tr>';
                
      }
    }
}

}else if(isset($_POST['f_distance'])){
  $distance=$_POST['f_distance'];
  $sql="INSERT INTO movement( move , distance ) VALUES('F','$distance')";
  $result=mysqli_query($con,$sql);
  if($result){
    $sql1="SELECT *  from movement ";
      $result1=mysqli_query($con,$sql1);
      if($result1){
      while($row=mysqli_fetch_assoc($result1)){
          echo '<tr>
                  <th>  '.$row['move'].'</th>
                  <th>  '.$row['distance'].'</th> 
                </tr>';
                
      }
    }
  }
}else if(isset($_POST['save'])){

  $left     =$_POST['ll_distance'];
  $right    =$_POST['rr_distance'];
  $forward  =$_POST['ff_distance'];

  if($left==''){
    $left=0;
  }else if($right==''){
    $right=0;
  }elseif($forward==''){
    $forward=0;
  }
  $sql="INSERT INTO movement( move , distance ) VALUES('R','$right'),('F', '$forward'), ('L', '$left')";
  $result=mysqli_query($con,$sql);
  if($result){
      $sql1="SELECT *  from movement ";
      $result1=mysqli_query($con,$sql1);
      if($result1){
      while($row=mysqli_fetch_assoc($result1)){
          echo '<tr>
                  <th>  '.$row['move'].'</th>
                  <th>  '.$row['distance'].'</th> 
                </tr>';
                
      }
    }
  }
}else if(isset($_POST['delete_button'])){
  $sql="DELETE FROM movement ";
  $result=mysqli_query($con,$sql);
  if($result){
    $sql1="SELECT *  from movement ";
      $result1=mysqli_query($con,$sql1);
      if($result1){
      while($row=mysqli_fetch_assoc($result1)){
          echo '<tr>
                  <th>  '.$row['move'].'</th>
                  <th>  '.$row['distance'].'</th> 
                </tr>';
                
      }
    }
  }
}
?>
