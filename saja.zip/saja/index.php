<!DOCTYPE html>
<html>
<head>
<script src="jquery.js"></script>
<style>
body {
  background-color: lightblue;
}
.button {
  background-color: #e7e7e7;/* Gray */ 
  border: none;
  color: white ;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  transition-duration: 0.4s;
  border-radius: 12px;
  align-self: center;
}

.input {
  padding: 15px 32px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  border-radius: 12px;
  align-self: center;
}

table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 20px;
}
#t01 {
  width: 20%; 
}
</style>
</head>
<body>


<div style="width: 40%;display: inline-block;float: left;">
  <button class="button" name="right" value="R"  id="right" onclick="test1();">Right</button>
  <input class="input" type="text" name="r_distance" id="r_distance">


  <p>
  <button class="button" name="forward" value="F" id="forward" onclick="test2();">Forwards</button>
  <input class="input" type="text" name="f_distance" id="f_distance">
  </p>

  <p>
  <button class="button" name="left" value="L" id="left" onclick="test3();">Left</button>
  <input class="input" type="text" name="l_distance" id="l_distance">
  </p>



  <p>
    <form method="post" style="display: inline-block;">
      <button class="button" name="delete" id="delete_button">Delete</button>
    </form>
  <button class="button" name="save"  id="save">Save</button>
  <button class="button" name="start"  >Start</button>
  </p>


  <table id="t01">
    <thead>
    <tr>
      <th>Movement</th>
      <th>Distance</th>
    </tr>
  </thead>
  <tbody id="table-body">
      <?php
      $con=mysqli_connect('localhost','root','','task2') or die("unable to connect");
      $sql1="SELECT *  from movement ";
        $result1=mysqli_query($con,$sql1);
        if($result1){
        while($row=mysqli_fetch_assoc($result1)){
            echo '<tr>
                    <th>  '.$row['move'].'</th>
                    <th>  '.$row['distance'].'</th> 
                  </tr>';
                  
        }
      }
      ?>
  </tbody>
  </table>

</div>

<div style="width: 60%;display: inline-block;float: left;">
  <canvas id="myCanvas" width="800" height="700" style="border:1px solid black;">
  Your browser does not support the HTML5 canvas tag.</canvas>
</div>

<script>
  $(document).ready(function() {

    // right button
         $('#right').click(function(){

          var r_distance = $("#r_distance").val();

          $.ajax({ 
            url: "insert.php",  
            type: "POST",
            data: {r_distance:r_distance},
            dataType:"html",
            success: function(data){
              $("#table-body").html(data);
            }
        });
    });

    // forward button
         $('#forward').click(function(){

          var f_distance = $("#f_distance").val();

          $.ajax({ 
            url: "insert.php",  
            type: "POST",
            data: {f_distance:f_distance},
            dataType:"html",
            success: function(data){
              $("#table-body").html(data);
            }
        });
    });

    // left button
         $('#left').click(function(){

          var l_distance = $("#l_distance").val();

          $.ajax({ 
            url: "insert.php",  
            type: "POST",
            data: {l_distance:l_distance},
            dataType:"html",
            success: function(data){
              $("#table-body").html(data);
            }
        });
    });

      // save button
         $('#save').click(function(){

          var rr_distance = $("#r_distance").val();
          var ff_distance = $("#f_distance").val();
          var ll_distance = $("#l_distance").val();
          var save = $("#save").val();

          $.ajax({ 
            url: "insert.php",  
            type: "POST",
            data: {
              rr_distance:rr_distance,
              ff_distance:ff_distance,
              ll_distance:ll_distance,
              save:save
            },
            dataType:"html",
            success: function(data){
              $("#table-body").html(data);
            }
        });
    });

    // delete_button button
         $('#delete_button').click(function(){

          var delete_button = $("#delete_button").val();
          $.ajax({ 
            url: "insert.php",  
            type: "POST",
            data: {
              delete_button:delete_button
            },
            dataType:"html",
            success: function(data){
              $("#table-body").html(data);
            }
        });
  
    });


    });

        
// drawing from here
  
  var test = [20,20];
  
  var oriention = 'vertical';

  function test1() {

    var right = document.getElementById("r_distance");
    if(right.value == '') {

    } else {
    var c = document.getElementById("myCanvas");
    var ctx = c.getContext("2d");
    ctx.beginPath();
    
      
      ctx.moveTo(test[0], test[1]);
      if(oriention == 'vertical') {
        ctx.lineTo(test[0], parseInt(test[1]) + parseInt(right.value) );
        test[1] = parseInt(test[1]) + parseInt(right.value);
        oriention = 'left-horizontal';

      } else if(oriention == 'left-vertical') {

        ctx.lineTo(test[0], parseInt(test[1]) + parseInt(Math.abs(right.value)) * -1 );
        test[1] = parseInt(test[1]) + parseInt(Math.abs(right.value)) * -1 ;
        oriention = 'horizontal';

      } else if(oriention == 'left-horizontal') {

        ctx.lineTo(parseInt(test[0]) + parseInt(Math.abs(right.value)) * -1, test[1]);
        test[0] = parseInt(test[0]) + parseInt(Math.abs(right.value)) * -1;
        oriention = 'left-vertical';
      } else {
        ctx.lineTo(parseInt(test[0]) + parseInt(right.value), test[1]);
        test[0] = parseInt(test[0]) + parseInt(right.value);
        oriention = 'vertical';
      }
      
   
    
    ctx.stroke();
     }
   }
    


  function test2() {

    var forward = document.getElementById("f_distance");
    if(forward.value == '') {

    } else {
    var c = document.getElementById("myCanvas");
    var ctx = c.getContext("2d");
    ctx.beginPath();
    
  
    ctx.moveTo(test[0], test[1]);

      if(oriention == 'vertical') {
        ctx.lineTo(parseInt(test[0]) + parseInt(forward.value), test[1] );
        test[0] = parseInt(test[0]) + parseInt(forward.value);
        oriention = 'vertical';
      } else if(oriention == 'left-vertical') {
        ctx.lineTo(parseInt(test[0]) + parseInt(Math.abs(forward.value)) * -1 , test[1] );
        test[0] = parseInt(test[0]) + parseInt(Math.abs(forward.value)) * -1 ;
        oriention = 'left-vertical';
      } else if(oriention == 'left-horizontal') {
        ctx.lineTo(test[0], parseInt(test[1]) + parseInt(forward.value));
        test[1] = parseInt(test[1]) + parseInt(forward.value);
        oriention = 'left-horizontal';
      }

      else {
        ctx.lineTo(test[0], parseInt(test[1]) + parseInt(Math.abs(forward.value)) * -1);
        test[1] = parseInt(test[1]) + parseInt(Math.abs(forward.value)) * -1;
        oriention = 'horizontal';
      }
      
    ctx.stroke();
    }
  }

  function test3() {
    var left = document.getElementById("l_distance");
    if(left.value == '') {

    } else {
    var c = document.getElementById("myCanvas");
    var ctx = c.getContext("2d");
    ctx.beginPath();
    

    ctx.moveTo(test[0], test[1]);

    if(oriention == 'vertical') {
      ctx.lineTo(test[0], parseInt(test[1]) + parseInt(Math.abs(left.value)) * -1);
      test[1] = parseInt(test[1]) + parseInt(Math.abs(left.value)) * -1;
      oriention = 'horizontal';
    } else if(oriention == 'left-vertical') {
      ctx.lineTo(test[0], parseInt(test[1]) +parseInt(left.value));
      test[1] = parseInt(test[1]) + parseInt(left.value);
      oriention = 'left-horizontal';
    } else if(oriention == 'left-horizontal') {
      ctx.lineTo(parseInt(test[0]) + parseInt(left.value), test[1]);
      test[0] = parseInt(test[0]) + parseInt(left.value);
      oriention = 'vertical';
      
    }

     else {
      ctx.lineTo(parseInt(test[0]) + parseInt(Math.abs(left.value))*-1, test[1]);
      test[0] = parseInt(test[0]) + parseInt(Math.abs(left.value))*-1;
      oriention = 'left-vertical';
    }

      
      
      ctx.stroke();
    }
  }
    
    /*ctx.lineTo(20, forward.value);
    ctx.lineTo(right.value, forward.value);
    ctx.lineTo(right.value, left.value);*/
          

          
</script>
</body>
</html>

